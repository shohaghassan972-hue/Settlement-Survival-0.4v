# Settlement Survival v0.2

Lightweight Android survival settlement prototype. Includes an isometric-style map, trees, river, houses, villagers, resources, day/night cycle, build mode and fast time.
