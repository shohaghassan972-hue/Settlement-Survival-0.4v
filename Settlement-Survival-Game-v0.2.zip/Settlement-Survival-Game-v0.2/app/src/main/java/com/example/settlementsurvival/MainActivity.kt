package com.example.settlementsurvival

import android.app.Activity
import android.os.Bundle
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.view.*
import android.content.Context
import kotlin.math.*

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setBackgroundDrawable(ColorDrawable(Color.rgb(74,125,78)))
        setContentView(GameView(this))
    }
}

data class Tree(val x: Float, val y: Float)
data class House(val x: Float, val y: Float)
data class Villager(var x: Float, var y: Float, var tx: Float, var ty: Float)

class GameView(context: Context) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val t = Paint(Paint.ANTI_ALIAS_FLAG)
    private val trees = mutableListOf<Tree>()
    private val houses = mutableListOf<House>()
    private val villagers = mutableListOf<Villager>()
    private var wood = 120
    private var food = 90
    private var water = 100
    private var population = 5
    private var day = 1
    private var hour = 8f
    private var buildMode = false
    private var fast = false
    private var last = System.currentTimeMillis()
    private var toast = ""
    private var toastUntil = 0L

    init {
        t.typeface = Typeface.create("sans", Typeface.BOLD)
        val r = java.util.Random(17)
        repeat(34) { trees += Tree(.13f+r.nextFloat()*.74f, .28f+r.nextFloat()*.55f) }
        houses += House(.50f,.53f); houses += House(.61f,.62f)
        repeat(population) { val x=.43f+r.nextFloat()*.25f; val y=.52f+r.nextFloat()*.22f; villagers += Villager(x,y,x,y) }
    }

    override fun onDraw(c: Canvas) {
        val now=System.currentTimeMillis(); val dt=((now-last).coerceAtMost(100L)/1000f)*(if(fast)2f else 1f); last=now
        update(dt); drawGame(c); postInvalidateDelayed(33)
    }

    private fun update(dt: Float) {
        hour += dt*.55f
        if(hour>=24f){ hour-=24f; day++; food=max(0,food-population*2); water=max(0,water-population); if(food==0||water==0) msg("Supplies are running low!") }
        villagers.forEach { v ->
            val dx=v.tx-v.x; val dy=v.ty-v.y; val d=sqrt(dx*dx+dy*dy)
            if(d<.01f){ val a=Math.random()*Math.PI*2; v.tx=(v.x+cos(a)*.08).coerceIn(.16,.84).toFloat(); v.ty=(v.y+sin(a)*.06).coerceIn(.34,.82).toFloat() }
            else { v.x += dx/d*dt*.035f; v.y += dy/d*dt*.035f }
        }
    }

    private fun drawGame(c: Canvas) {
        val w=width.toFloat(); val h=height.toFloat(); val night=hour<6||hour>=19
        c.drawColor(if(night)Color.rgb(30,52,60) else Color.rgb(92,151,92))
        p.color=Color.argb(225,24,31,29); c.drawRect(0f,0f,w,h*.17f,p)
        t.color=Color.WHITE; t.textSize=sp(20f); c.drawText("SETTLEMENT SURVIVAL",dp(16f),dp(27f),t)
        t.textSize=sp(14f); c.drawText("Day $day  •  ${hour.toInt().toString().padStart(2,'0')}:${((hour%1)*60).toInt().toString().padStart(2,'0')}",dp(18f),dp(51f),t)
        stat(c,.33f,"👥 $population","People"); stat(c,.48f,"🪵 $wood","Wood"); stat(c,.63f,"🍖 $food","Food"); stat(c,.78f,"💧 $water","Water")
        val l=w*.08f; val r=w*.92f; val top=h*.18f; val bot=h*.90f
        p.color=if(night)Color.rgb(47,91,58) else Color.rgb(82,137,73); c.drawRect(l,top,r,bot,p)
        for(row in 0 until 9) for(col in 0 until 12){ val cx=l+(col+.5f)*(r-l)/12; val cy=top+(row+.5f)*(bot-top)/9; val tw=(r-l)/12; val th=(bot-top)/9; val q=Path(); q.moveTo(cx,cy-th*.36f); q.lineTo(cx+tw*.48f,cy); q.lineTo(cx,cy+th*.36f); q.lineTo(cx-tw*.48f,cy); q.close(); p.color=if((row+col)%2==0)Color.argb(22,255,255,255)else Color.argb(12,0,0,0); c.drawPath(q,p) }
        p.color=Color.argb(170,70,155,210); val river=Path(); river.moveTo(l,h*.73f); river.cubicTo(w*.30f,h*.63f,w*.54f,h*.82f,r,h*.69f); c.drawPath(river,p)
        trees.forEach { tree(c,w*it.x,h*it.y,night) }; houses.forEach { house(c,w*it.x,h*it.y) }; villagers.forEach { villager(c,w*it.x,h*it.y) }
        button(c,w*.78f,h*.91f,w*.11f,h*.065f,if(buildMode)"CANCEL" else "BUILD")
        button(c,w*.90f,h*.91f,w*.07f,h*.065f,if(fast)"▶▶" else "▶")
        if(buildMode){ p.color=Color.argb(225,30,30,30); c.drawRoundRect(w*.20f,h*.90f,w*.72f,h*.985f,dp(10f),dp(10f),p); t.color=Color.WHITE;t.textSize=sp(14f);c.drawText("Tap empty land to build • Cost: 40 wood",w*.23f,h*.95f,t) }
        if(System.currentTimeMillis()<toastUntil){ p.color=Color.argb(220,0,0,0);c.drawRoundRect(w*.25f,h*.20f,w*.75f,h*.27f,dp(12f),dp(12f),p);t.color=Color.WHITE;t.textSize=sp(15f);t.textAlign=Paint.Align.CENTER;c.drawText(toast,w*.5f,h*.245f,t);t.textAlign=Paint.Align.LEFT }
    }

    private fun stat(c:Canvas,x:Float,v:String,label:String){ t.color=Color.WHITE;t.textSize=sp(15f);c.drawText(v,width*x,dp(25f),t);t.color=Color.LTGRAY;t.textSize=sp(10f);c.drawText(label,width*x,dp(43f),t) }
    private fun tree(c:Canvas,x:Float,y:Float,night:Boolean){p.color=Color.rgb(92,63,39);c.drawRect(x-dp(4f),y,x+dp(4f),y+dp(19f),p);p.color=if(night)Color.rgb(32,80,40)else Color.rgb(25,112,45);c.drawCircle(x,y-dp(8f),dp(18f),p);c.drawCircle(x-dp(11f),y,dp(13f),p);c.drawCircle(x+dp(11f),y,dp(13f),p)}
    private fun house(c:Canvas,x:Float,y:Float){p.color=Color.rgb(198,154,91);c.drawRect(x-dp(28f),y-dp(4f),x+dp(28f),y+dp(27f),p);val q=Path();q.moveTo(x-dp(35f),y-dp(4f));q.lineTo(x,y-dp(30f));q.lineTo(x+dp(35f),y-dp(4f));q.close();p.color=Color.rgb(125,65,45);c.drawPath(q,p);p.color=Color.rgb(70,48,34);c.drawRect(x-dp(7f),y+dp(10f),x+dp(7f),y+dp(27f),p);p.color=Color.rgb(130,190,210);c.drawRect(x-dp(21f),y+dp(3f),x-dp(10f),y+dp(13f),p);c.drawRect(x+dp(10f),y+dp(3f),x+dp(21f),y+dp(13f),p)}
    private fun villager(c:Canvas,x:Float,y:Float){p.color=Color.rgb(238,194,150);c.drawCircle(x,y-dp(10f),dp(6f),p);p.color=Color.rgb(55,91,155);c.drawRoundRect(x-dp(7f),y-dp(4f),x+dp(7f),y+dp(12f),dp(4f),dp(4f),p);p.color=Color.DKGRAY;c.drawRect(x-dp(6f),y+dp(11f),x-dp(2f),y+dp(19f),p);c.drawRect(x+dp(2f),y+dp(11f),x+dp(6f),y+dp(19f),p)}
    private fun button(c:Canvas,cx:Float,cy:Float,bw:Float,bh:Float,label:String){p.color=Color.argb(235,35,42,39);c.drawRoundRect(cx-bw/2,cy-bh/2,cx+bw/2,cy+bh/2,dp(10f),dp(10f),p);p.color=Color.WHITE;p.style=Paint.Style.STROKE;p.strokeWidth=dp(1.5f);c.drawRoundRect(cx-bw/2,cy-bh/2,cx+bw/2,cy+bh/2,dp(10f),dp(10f),p);p.style=Paint.Style.FILL;t.color=Color.WHITE;t.textSize=sp(12f);t.textAlign=Paint.Align.CENTER;c.drawText(label,cx,cy+sp(4f),t);t.textAlign=Paint.Align.LEFT}

    override fun onTouchEvent(e:MotionEvent):Boolean{ if(e.action!=MotionEvent.ACTION_UP)return true; val x=e.x/width;val y=e.y/height
        if(y>.875f&&x>.73f&&x<.85f){buildMode=!buildMode;msg(if(buildMode)"Build mode ON"else"Build mode OFF");return true}
        if(y>.875f&&x>=.85f){fast=!fast;msg(if(fast)"Fast time"else"Normal time");return true}
        if(buildMode&&y>.18f&&y<.90f&&x>.08f&&x<.92f){ if(houses.any{abs(it.x-x)<.09f&&abs(it.y-y)<.08f}){msg("That space is occupied");return true};if(wood>=40){wood-=40;houses+=House(x,y);population+=2;villagers+=Villager(x,y+.05f,x+.03f,y+.02f);villagers+=Villager(x-.03f,y+.05f,x-.02f,y+.02f);food+=10;water+=12;msg("House built! +2 population")}else msg("Not enough wood");buildMode=false;return true};return true }
    private fun msg(s:String){toast=s;toastUntil=System.currentTimeMillis()+1800}
    private fun dp(v:Float)=v*resources.displayMetrics.density
    private fun sp(v:Float)=v*resources.displayMetrics.scaledDensity
}
