package com.example.settlementsurvival

import android.app.Activity
import android.os.Bundle
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.view.*
import android.content.Context
import kotlin.math.*

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setBackgroundDrawable(ColorDrawable(Color.rgb(74,125,78)))
        setContentView(GameView(this))
    }
}

data class Tree(val x: Float, val y: Float)
data class House(val x: Float, val y: Float)
data class Villager(var x: Float, var y: Float, var attackTimer: Float = 0f)
data class Monster(var x: Float, var y: Float, var hp: Int = 3, var tx: Float = x, var ty: Float = y, var timer: Float = 0f)

class GameView(context: Context) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val t = Paint(Paint.ANTI_ALIAS_FLAG)
    private val trees = mutableListOf<Tree>()
    private val houses = mutableListOf<House>()
    private val villagers = mutableListOf<Villager>()
    private val monsters = mutableListOf<Monster>()

    private var wood = 120
    private var food = 0
    private var water = 100
    private val maxPopulation = 4
    private var population = 4
    private var day = 1
    private var hour = 8f
    private var fast = false
    private var last = System.currentTimeMillis()
    private var toast = ""
    private var toastUntil = 0L

    init {
        t.typeface = Typeface.create("sans", Typeface.BOLD)
        val r = java.util.Random(17)
        repeat(34) { trees += Tree(.13f + r.nextFloat()*.74f, .28f + r.nextFloat()*.55f) }
        // v0.3: exactly one house and exactly four villagers.
        houses += House(.50f, .53f)
        listOf(.45f to .51f, .55f to .51f, .47f to .60f, .53f to .60f)
            .forEach { villagers += Villager(it.first, it.second) }

        // Monsters stay in the forest and avoid the house/river.
        repeat(10) {
            var x: Float
            var y: Float
            do {
                x = .16f + r.nextFloat()*.68f
                y = .34f + r.nextFloat()*.47f
            } while (dist(x,y,.50f,.53f) < .16f || (y > .62f && y < .76f))
            monsters += Monster(x,y)
        }
    }

    override fun onDraw(c: Canvas) {
        val now = System.currentTimeMillis()
        val dt = ((now-last).coerceAtMost(100L)/1000f) * if (fast) 2f else 1f
        last = now
        update(dt)
        drawGame(c)
        postInvalidateDelayed(33)
    }

    private fun update(dt: Float) {
        hour += dt*.55f
        if (hour >= 24f) {
            hour -= 24f
            day++
            food = max(0, food - population*2)
            water = max(0, water - population)
            if (food == 0) msg("Food is empty — hunt monsters!")
        }
        updateMonsters(dt)
        updateVillagers(dt)
    }

    private fun updateVillagers(dt: Float) {
        villagers.forEachIndexed { i, v ->
            val target = nearestMonster(v.x,v.y)
            if (target >= 0) {
                val m = monsters[target]
                val dx = m.x-v.x
                val dy = m.y-v.y
                val d = sqrt(dx*dx+dy*dy)
                if (d > .035f) {
                    v.x += dx/d*dt*.045f
                    v.y += dy/d*dt*.045f
                } else {
                    v.attackTimer -= dt
                    if (v.attackTimer <= 0f) {
                        m.hp--
                        v.attackTimer = .75f
                        if (m.hp <= 0) {
                            food += 8
                            msg("+8 food — monster defeated")
                        }
                    }
                }
            } else {
                val hx = .50f + (i-1.5f)*.035f
                val hy = .58f
                val dx = hx-v.x
                val dy = hy-v.y
                val d = sqrt(dx*dx+dy*dy)
                if (d > .01f) {
                    v.x += dx/d*dt*.025f
                    v.y += dy/d*dt*.025f
                }
            }
            v.x = v.x.coerceIn(.12f,.88f)
            v.y = v.y.coerceIn(.31f,.84f)
        }
        monsters.removeAll { it.hp <= 0 }
        population = min(maxPopulation, villagers.size)
    }

    private fun updateMonsters(dt: Float) {
        monsters.forEach { m ->
            m.timer -= dt
            if (m.timer <= 0f) {
                val a = Math.random()*Math.PI*2.0
                m.tx = (m.x + cos(a).toFloat()*.08f).coerceIn(.15f,.85f)
                m.ty = (m.y + sin(a).toFloat()*.06f).coerceIn(.34f,.82f)
                m.timer = 2f + Math.random().toFloat()*2.5f
            }
            val dx = m.tx-m.x
            val dy = m.ty-m.y
            val d = sqrt(dx*dx+dy*dy)
            if (d > .008f) {
                m.x += dx/d*dt*.010f
                m.y += dy/d*dt*.010f
            }
        }
    }

    private fun nearestMonster(x: Float, y: Float): Int {
        var best = -1
        var bestD = Float.MAX_VALUE
        monsters.forEachIndexed { i,m ->
            val d = dist(x,y,m.x,m.y)
            if (d < bestD) { bestD=d; best=i }
        }
        return best
    }

    private fun dist(x1:Float,y1:Float,x2:Float,y2:Float):Float =
        sqrt((x2-x1).pow(2)+(y2-y1).pow(2))

    private fun drawGame(c: Canvas) {
        val w=width.toFloat(); val h=height.toFloat()
        val night=hour<6f || hour>=19f
        c.drawColor(if(night) Color.rgb(30,52,60) else Color.rgb(92,151,92))
        p.color=Color.argb(225,24,31,29); c.drawRect(0f,0f,w,h*.17f,p)
        t.color=Color.WHITE; t.textSize=sp(20f); c.drawText("SETTLEMENT SURVIVAL",dp(16f),dp(27f),t)
        t.textSize=sp(14f)
        val minute=((hour%1f)*60f).toInt().coerceIn(0,59)
        c.drawText("Day $day  •  ${hour.toInt().toString().padStart(2,'0')}:${minute.toString().padStart(2,'0')}",dp(18f),dp(51f),t)
        stat(c,.22f,"$population/$maxPopulation","People")
        stat(c,.40f,"$wood","Wood")
        stat(c,.58f,"$food","Food")
        stat(c,.76f,"$water","Water")
        stat(c,.91f,"${monsters.size}","Monsters")

        val l=w*.08f; val r=w*.92f; val top=h*.18f; val bot=h*.90f
        p.color=if(night) Color.rgb(47,91,58) else Color.rgb(82,137,73); c.drawRect(l,top,r,bot,p)
        for(row in 0 until 9) for(col in 0 until 12) {
            val cx=l+(col+.5f)*(r-l)/12f; val cy=top+(row+.5f)*(bot-top)/9f
            val tw=(r-l)/12f; val th=(bot-top)/9f
            val q=Path(); q.moveTo(cx,cy-th*.36f); q.lineTo(cx+tw*.48f,cy); q.lineTo(cx,cy+th*.36f); q.lineTo(cx-tw*.48f,cy); q.close()
            p.color=if((row+col)%2==0) Color.argb(22,255,255,255) else Color.argb(12,0,0,0)
            c.drawPath(q,p)
        }
        // One river.
        p.color=Color.argb(185,70,155,210)
        val river=Path(); river.moveTo(l,h*.73f); river.cubicTo(w*.30f,h*.63f,w*.54f,h*.82f,r,h*.69f); c.drawPath(river,p)
        trees.forEach { tree(c,w*it.x,h*it.y,night) }
        houses.forEach { house(c,w*it.x,h*it.y) }
        monsters.forEach { monster(c,w*it.x,h*it.y,it.hp) }
        villagers.forEach { villager(c,w*it.x,h*it.y) }

        // No BUILD button in v0.3; population stays capped at 4.
        button(c,w*.90f,h*.91f,w*.10f,h*.065f,if(fast) "▶▶" else "▶")

        if (monsters.isEmpty()) {
            p.color=Color.argb(210,20,35,25); c.drawRoundRect(w*.23f,h*.20f,w*.77f,h*.27f,dp(12f),dp(12f),p)
            t.color=Color.WHITE; t.textSize=sp(14f); t.textAlign=Paint.Align.CENTER
            c.drawText("Forest cleared — no monsters left",w*.5f,h*.245f,t); t.textAlign=Paint.Align.LEFT
        }
        if(System.currentTimeMillis()<toastUntil) {
            p.color=Color.argb(220,0,0,0); c.drawRoundRect(w*.22f,h*.28f,w*.78f,h*.35f,dp(12f),dp(12f),p)
            t.color=Color.WHITE; t.textSize=sp(15f); t.textAlign=Paint.Align.CENTER
            c.drawText(toast,w*.5f,h*.325f,t); t.textAlign=Paint.Align.LEFT
        }
    }

    private fun stat(c:Canvas,x:Float,v:String,label:String) {
        t.color=Color.WHITE; t.textSize=sp(14f); t.textAlign=Paint.Align.CENTER; c.drawText(v,width*x,dp(25f),t)
        t.color=Color.LTGRAY; t.textSize=sp(9f); c.drawText(label,width*x,dp(43f),t); t.textAlign=Paint.Align.LEFT
    }

    private fun tree(c:Canvas,x:Float,y:Float,night:Boolean) {
        p.color=Color.rgb(92,63,39); c.drawRect(x-dp(4f),y,x+dp(4f),y+dp(19f),p)
        p.color=if(night) Color.rgb(32,80,40) else Color.rgb(25,112,45)
        c.drawCircle(x,y-dp(8f),dp(18f),p); c.drawCircle(x-dp(11f),y,dp(13f),p); c.drawCircle(x+dp(11f),y,dp(13f),p)
    }

    private fun house(c:Canvas,x:Float,y:Float) {
        p.color=Color.rgb(198,154,91); c.drawRect(x-dp(28f),y-dp(4f),x+dp(28f),y+dp(27f),p)
        val q=Path(); q.moveTo(x-dp(35f),y-dp(4f)); q.lineTo(x,y-dp(30f)); q.lineTo(x+dp(35f),y-dp(4f)); q.close()
        p.color=Color.rgb(125,65,45); c.drawPath(q,p)
        p.color=Color.rgb(70,48,34); c.drawRect(x-dp(7f),y+dp(10f),x+dp(7f),y+dp(27f),p)
        p.color=Color.rgb(130,190,210); c.drawRect(x-dp(21f),y+dp(3f),x-dp(10f),y+dp(13f),p); c.drawRect(x+dp(10f),y+dp(3f),x+dp(21f),y+dp(13f),p)
    }

    private fun villager(c:Canvas,x:Float,y:Float) {
        p.color=Color.rgb(55,91,155); c.drawRoundRect(x-dp(7f),y-dp(4f),x+dp(7f),y+dp(12f),dp(4f),dp(4f),p)
        p.color=Color.rgb(238,194,150); c.drawCircle(x,y-dp(10f),dp(6f),p)
        p.color=Color.DKGRAY; c.drawRect(x-dp(6f),y+dp(11f),x-dp(2f),y+dp(19f),p); c.drawRect(x+dp(2f),y+dp(11f),x+dp(6f),y+dp(19f),p)
    }

    private fun monster(c:Canvas,x:Float,y:Float,hp:Int) {
        p.color=Color.rgb(115,42,48); c.drawCircle(x,y,dp(12f),p)
        val q=Path(); q.moveTo(x-dp(8f),y-dp(7f)); q.lineTo(x-dp(14f),y-dp(19f)); q.lineTo(x-dp(2f),y-dp(12f)); q.close(); c.drawPath(q,p)
        q.reset(); q.moveTo(x+dp(8f),y-dp(7f)); q.lineTo(x+dp(14f),y-dp(19f)); q.lineTo(x+dp(2f),y-dp(12f)); q.close(); c.drawPath(q,p)
        p.color=Color.YELLOW; c.drawCircle(x-dp(4f),y-dp(2f),dp(2f),p); c.drawCircle(x+dp(4f),y-dp(2f),dp(2f),p)
        p.color=Color.argb(180,0,0,0); c.drawRect(x-dp(13f),y-dp(26f),x+dp(13f),y-dp(22f),p)
        p.color=Color.rgb(225,70,70); c.drawRect(x-dp(13f),y-dp(26f),x-dp(13f)+dp(26f)*(hp/3f),y-dp(22f),p)
    }

    private fun button(c:Canvas,cx:Float,cy:Float,bw:Float,bh:Float,label:String) {
        p.color=Color.argb(235,35,42,39); c.drawRoundRect(cx-bw/2,cy-bh/2,cx+bw/2,cy+bh/2,dp(10f),dp(10f),p)
        p.color=Color.WHITE; p.style=Paint.Style.STROKE; p.strokeWidth=dp(1.5f)
        c.drawRoundRect(cx-bw/2,cy-bh/2,cx+bw/2,cy+bh/2,dp(10f),dp(10f),p); p.style=Paint.Style.FILL
        t.color=Color.WHITE; t.textSize=sp(12f); t.textAlign=Paint.Align.CENTER; c.drawText(label,cx,cy+sp(4f),t); t.textAlign=Paint.Align.LEFT
    }

    override fun onTouchEvent(e:MotionEvent):Boolean {
        if(e.action!=MotionEvent.ACTION_UP) return true
        val x=e.x/width; val y=e.y/height
        if(y>.875f && x>=.85f) { fast=!fast; msg(if(fast) "Fast time" else "Normal time") }
        return true
    }

    private fun msg(s:String) { toast=s; toastUntil=System.currentTimeMillis()+1800L }
    private fun dp(v:Float)=v*resources.displayMetrics.density
    private fun sp(v:Float)=v*resources.displayMetrics.scaledDensity
}
