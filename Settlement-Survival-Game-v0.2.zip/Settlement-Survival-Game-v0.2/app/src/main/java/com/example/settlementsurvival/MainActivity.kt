package com.example.settlementsurvival

import android.app.Activity
import android.os.Bundle
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.view.*
import android.content.Context
import kotlin.math.*
import java.util.Random

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setBackgroundDrawable(ColorDrawable(Color.rgb(70,125,78)))
        setContentView(GameView(this))
    }
}

enum class BeastPower { FIRE, WATER, LIGHTNING, ICE, DARK, LIGHT, NATURE, EARTH }
data class Tree(val x:Float,val y:Float)
data class Building(val x:Float,val y:Float,val type:String)
data class CharacterUnit(var x:Float,var y:Float,val name:String,val magic:String,var level:Int=1,var xp:Int=0,var attackTimer:Float=0f,var hp:Int=100,var maxHp:Int=100)
data class MagicBeast(var x:Float,var y:Float,val power:BeastPower,var hp:Int,val maxHp:Int,var tx:Float,var ty:Float,var wanderTimer:Float=0f,var attackTimer:Float=0f,var revealed:Boolean=false)

class GameView(context:Context):View(context){
 private val save=context.getSharedPreferences("settlement_survival_save",Context.MODE_PRIVATE)
 private val saveSchema=1
 private var saveTimer=0f
 private var quest=1
 private var questKills=0
 private val p=Paint(Paint.ANTI_ALIAS_FLAG); private val t=Paint(Paint.ANTI_ALIAS_FLAG)
 private val trees=mutableListOf<Tree>(); private val buildings=mutableListOf<Building>(); private val villagers=mutableListOf<CharacterUnit>(); private val beasts=mutableListOf<MagicBeast>()
 private val random=Random(404)
 private var rawMeat=0; private var food=12; private var riverWater=0; private var cleanWater=60
 private var day=1; private var hour=8f; private var fast=false; private var last=System.currentTimeMillis()
 private var selectedBeast=-1; private var playerTargetX=.50f; private var playerTargetY=.56f; private var attackMode=false
 private var toast=""; private var toastUntil=0L
 init{
  t.typeface=Typeface.create("sans",Typeface.BOLD)
  repeat(42){trees+=Tree(.07f+random.nextFloat()*.23f,.29f+random.nextFloat()*.53f)}
  buildings+=Building(.50f,.52f,"HOUSE"); buildings+=Building(.42f,.61f,"COOK"); buildings+=Building(.58f,.61f,"PURIFY")
  villagers+=CharacterUnit(.50f,.55f,"PLAYER","DARK"); villagers+=CharacterUnit(.46f,.58f,"NPC1","WATER"); villagers+=CharacterUnit(.54f,.58f,"NPC2","LIGHT"); villagers+=CharacterUnit(.50f,.63f,"NPC3","FIRE")
  spawnBeasts()
 }
 private fun spawnBeasts(){
  beasts.clear(); val powers=BeastPower.values(); repeat(8){i->val hp=35+i*3; val x=.10f+random.nextFloat()*.17f; val y=.33f+random.nextFloat()*.46f; beasts+=MagicBeast(x,y,powers[i%powers.size],hp,hp,x,y)}
 }

 private fun saveGame(){
  val e=save.edit()
  e.putInt("schema",saveSchema)
  e.putInt("day",day).putFloat("hour",hour)
   .putInt("wood",wood).putInt("rawMeat",rawMeat).putInt("food",food)
   .putInt("riverWater",riverWater).putInt("cleanWater",cleanWater)
   .putInt("quest",quest).putInt("questKills",questKills)
  villagers.forEachIndexed{i,u->
   e.putFloat("u${i}x",u.x).putFloat("u${i}y",u.y)
    .putInt("u${i}level",u.level).putInt("u${i}xp",u.xp)
    .putInt("u${i}hp",u.hp).putInt("u${i}maxHp",u.maxHp)
  }
  e.apply()
 }
 private fun loadGame(){
  if(!save.contains("day"))return
  day=save.getInt("day",1).coerceAtLeast(1)
  hour=save.getFloat("hour",8f).coerceIn(0f,23.99f)
  wood=save.getInt("wood",80).coerceAtLeast(0)
  rawMeat=save.getInt("rawMeat",0).coerceAtLeast(0)
  food=save.getInt("food",12).coerceAtLeast(0)
  riverWater=save.getInt("riverWater",0).coerceIn(0,100)
  cleanWater=save.getInt("cleanWater",60).coerceIn(0,100)
  quest=save.getInt("quest",1).coerceAtLeast(1)
  questKills=save.getInt("questKills",0).coerceAtLeast(0)
  villagers.forEachIndexed{i,u->
   u.x=save.getFloat("u${i}x",u.x).coerceIn(.08f,.92f)
   u.y=save.getFloat("u${i}y",u.y).coerceIn(.30f,.86f)
   u.level=save.getInt("u${i}level",1).coerceAtLeast(1)
   u.xp=save.getInt("u${i}xp",0).coerceAtLeast(0)
   u.maxHp=save.getInt("u${i}maxHp",100).coerceAtLeast(100)
   u.hp=save.getInt("u${i}hp",u.maxHp).coerceIn(1,u.maxHp)
  }
 }

 override fun onDraw(c:Canvas){val now=System.currentTimeMillis();val dt=((now-last).coerceAtMost(80L)/1000f)*(if(fast)2f else 1f);last=now;update(dt);drawGame(c);postInvalidateDelayed(33)}
 private fun update(dt:Float){
  hour+=dt*.50f
  if(hour>=24f){hour-=24f;day++;food=max(0,food-4);cleanWater=max(0,cleanWater-4);if(food==0)msg("Food is empty");if(cleanWater==0)msg("Clean water is empty")}
  if(hour>=7f&&hour<18f&&riverWater<100)riverWater=min(100,riverWater+1)
  if(rawMeat>0&&hour>=6f&&hour<20f){rawMeat--;food+=2}
  updatePlayer(dt);updateNpc(dt);updateBeasts(dt);resolveCombat(dt);cleanWater=min(100,cleanWater+if(riverWater>=10)1 else 0);if(riverWater>=10)riverWater--
  if(beasts.isEmpty()){spawnBeasts();msg("New Magic Beasts appeared in the forest")}
 }
 private fun updatePlayer(dt:Float){
  val u=villagers[0];val dx=playerTargetX-u.x;val dy=playerTargetY-u.y;val d=sqrt(dx*dx+dy*dy);if(d>.008f){u.x+=dx/d*dt*.060f;u.y+=dy/d*dt*.060f};u.x=u.x.coerceIn(.08f,.92f);u.y=u.y.coerceIn(.30f,.86f)
  if(u.x<.34f)beasts.forEach{it.revealed=true};if(selectedBeast in beasts.indices&&dist(u.x,u.y,beasts[selectedBeast].x,beasts[selectedBeast].y)<.30f)beasts[selectedBeast].revealed=true
  if(attackMode)selectedBeast=nearestVisibleBeast(u.x,u.y)
 }
 private fun updateNpc(dt:Float){
  val player=villagers[0]
  for(i in 1 until villagers.size){val n=villagers[i];val enemy=nearestVisibleBeast(n.x,n.y)
   if(enemy>=0){val b=beasts[enemy];val dx=b.x-n.x;val dy=b.y-n.y;val d=sqrt(dx*dx+dy*dy);if(d>.055f){n.x+=dx/d*dt*.045f;n.y+=dy/d*dt*.045f}}
   else{val ox=if(i==1)-.045f else if(i==2).045f else 0f;val tx=player.x+ox;val ty=player.y+.055f;val dx=tx-n.x;val dy=ty-n.y;val d=sqrt(dx*dx+dy*dy);if(d>.012f){n.x+=dx/d*dt*.035f;n.y+=dy/d*dt*.035f}}
   n.x=n.x.coerceIn(.08f,.92f);n.y=n.y.coerceIn(.30f,.86f)
  }
 }
 private fun updateBeasts(dt:Float){beasts.forEach{b->b.wanderTimer-=dt;if(b.wanderTimer<=0f){val a=random.nextDouble()*Math.PI*2;b.tx=(b.x+cos(a).toFloat()*.07f).coerceIn(.08f,.31f);b.ty=(b.y+sin(a).toFloat()*.07f).coerceIn(.30f,.84f);b.wanderTimer=1.5f+random.nextFloat()*2.5f;if(random.nextFloat()<.12f){b.revealed=true;b.tx=.40f+random.nextFloat()*.20f;b.ty=.48f+random.nextFloat()*.20f}};val dx=b.tx-b.x;val dy=b.ty-b.y;val d=sqrt(dx*dx+dy*dy);if(d>.006f){b.x+=dx/d*dt*.018f;b.y+=dy/d*dt*.018f};if(b.x<.33f&&dist(b.x,b.y,villagers[0].x,villagers[0].y)>.28f&&random.nextFloat()<.01f*dt)b.revealed=false}}
 private fun resolveCombat(dt:Float){if(beasts.isEmpty())return
  if(attackMode){val target=nearestVisibleBeast(villagers[0].x,villagers[0].y);if(target>=0){selectedBeast=target;val b=beasts[target];villagers.forEach{u->u.attackTimer-=dt;if(u.attackTimer<=0f&&dist(u.x,u.y,b.x,b.y)<.18f){val damage=when(u.magic){"DARK"->12+u.level*3;"WATER"->8+u.level*2;"LIGHT"->9+u.level*2;"FIRE"->11+u.level*3;else->7};b.hp-=damage;u.attackTimer=.65f;gainXp(u,10)}}}}
  beasts.forEach{b->val near=villagers.minByOrNull{u->dist(u.x,u.y,b.x,b.y)};if(near!=null&&dist(near.x,near.y,b.x,b.y)<.15f){b.attackTimer-=dt;if(b.attackTimer<=0f){near.hp-=4+powerBonus(b.power);b.attackTimer=1.1f;attackMode=true;selectedBeast=beasts.indexOf(b);msg("${powerName(b.power)} Beast attacks — team defending")}}}
  val dead=beasts.filter{it.hp<=0};if(dead.isNotEmpty()){dead.forEach{rawMeat+=2;questKills++;villagers.forEach{u->gainXp(u,15)}}
   if(questKills>=quest*3){quest++;questKills=0;wood+=10;food+=4;msg("RPG Quest complete! Reward +10 wood +4 food")}
   beasts.removeAll(dead.toSet());selectedBeast=-1;attackMode=false;msg("+${dead.size*2} monster meat")}
  villagers.forEach{it.hp=it.hp.coerceIn(0,it.maxHp);if(it.hp==0){it.hp=it.maxHp;msg("${it.name} recovered at the settlement")}}
 }
 private fun gainXp(u:CharacterUnit,amount:Int){u.xp+=amount;val need=u.level*50;if(u.xp>=need){u.xp-=need;u.level++;u.maxHp+=10;u.hp=u.maxHp;msg("${u.name} reached Level ${u.level}")}}
 private fun nearestVisibleBeast(x:Float,y:Float):Int{var best=-1;var bestD=Float.MAX_VALUE;beasts.forEachIndexed{i,b->if(b.revealed){val d=dist(x,y,b.x,b.y);if(d<bestD){bestD=d;best=i}}};return best}
 private fun dist(x1:Float,y1:Float,x2:Float,y2:Float)=sqrt((x2-x1).pow(2)+(y2-y1).pow(2))
 private fun drawGame(c:Canvas){
  val w=width.toFloat();val h=height.toFloat();val night=hour<6f||hour>=19f;c.drawColor(if(night)Color.rgb(25,45,33)else Color.rgb(94,155,91));p.color=Color.argb(235,24,31,28);c.drawRect(0f,0f,w,h*.18f,p)
  t.color=Color.WHITE;t.textSize=sp(19f);c.drawText("SETTLEMENT SURVIVAL  v0.4",dp(12f),dp(25f),t);t.textSize=sp(12f);c.drawText("Day $day • ${hour.toInt().toString().padStart(2,'0')}:${((hour%1f)*60).toInt().toString().padStart(2,'0')}",dp(14f),dp(46f),t)
  stat(c,.10f,"4","Team");stat(c,.25f,"$food","Food");stat(c,.40f,"$rawMeat","Meat");stat(c,.55f,"$cleanWater","Clean");stat(c,.70f,"$riverWater","River");stat(c,.85f,"${beasts.count{it.revealed}}","Beasts")
  val left=w*.04f;val right=w*.96f;val top=h*.20f;val bottom=h*.88f;p.color=if(night)Color.rgb(45,88,52)else Color.rgb(104,166,92);c.drawRect(left,top,right,bottom,p)
  p.color=if(night)Color.rgb(27,72,36)else Color.rgb(44,117,49);c.drawRect(left,top,w*.31f,bottom,p);trees.forEach{tree(c,w*it.x,h*it.y,night)}
  p.color=if(night)Color.rgb(48,104,132)else Color.rgb(65,153,205);val river=Path();river.moveTo(w*.78f,top);river.cubicTo(w*.69f,h*.36f,w*.88f,h*.56f,w*.78f,bottom);c.drawPath(river,p)
  val fx=w*.50f;val fy=h*.55f;val fr=min(w,h)*.17f;p.color=Color.argb(35,255,255,255);c.drawCircle(fx,fy,fr+dp(8f),p);p.color=Color.rgb(118,82,47);p.style=Paint.Style.STROKE;p.strokeWidth=dp(5f);c.drawCircle(fx,fy,fr,p);p.style=Paint.Style.FILL
  buildings.forEach{drawBuilding(c,w*it.x,h*it.y,it.type)};beasts.filter{it.revealed}.forEach{drawBeast(c,w*it.x,h*it.y,it)};villagers.forEachIndexed{i,u->drawCharacter(c,w*u.x,h*u.y,u,i==0)}
  if(selectedBeast in beasts.indices&&beasts[selectedBeast].revealed){val b=beasts[selectedBeast];p.color=Color.WHITE;p.style=Paint.Style.STROKE;p.strokeWidth=dp(2f);c.drawCircle(w*b.x,h*b.y,dp(20f),p);p.style=Paint.Style.FILL}
  button(c,w*.72f,h*.93f,w*.20f,h*.07f,if(attackMode)"ATTACKING"else"ATTACK");button(c,w*.89f,h*.93f,w*.11f,h*.07f,if(fast)"\u003e\u003e"else"\u003e")
  p.color=Color.argb(205,20,28,23);c.drawRoundRect(w*.03f,h*.78f,w*.34f,h*.87f,dp(8f),dp(8f),p);t.color=Color.WHITE;t.textSize=sp(10f);t.textSize=sp(9f);c.drawText("RPG Quest $quest • ${questKills}/${quest*3} Beast kills",w*.045f,h*.787f,t);t.textSize=sp(10f);villagers.forEachIndexed{i,u->c.drawText("${u.name} ${u.magic}  Lv${u.level}  XP${u.xp}",w*.045f,h*.795f+i*dp(15f),t)}
  if(System.currentTimeMillis()<toastUntil){p.color=Color.argb(225,0,0,0);c.drawRoundRect(w*.24f,h*.21f,w*.76f,h*.27f,dp(10f),dp(10f),p);t.color=Color.WHITE;t.textSize=sp(12f);t.textAlign=Paint.Align.CENTER;c.drawText(toast,w*.50f,h*.245f,t);t.textAlign=Paint.Align.LEFT}
 }
 private fun stat(c:Canvas,x:Float,value:String,label:String){t.color=Color.WHITE;t.textSize=sp(13f);t.textAlign=Paint.Align.CENTER;c.drawText(value,width*x,dp(70f),t);t.color=Color.LTGRAY;t.textSize=sp(8f);c.drawText(label,width*x,dp(82f),t);t.textAlign=Paint.Align.LEFT}
 private fun tree(c:Canvas,x:Float,y:Float,night:Boolean){p.color=Color.rgb(91,62,39);c.drawRect(x-dp(3f),y,x+dp(3f),y+dp(15f),p);p.color=if(night)Color.rgb(24,72,34)else Color.rgb(25,105,42);c.drawCircle(x,y-dp(7f),dp(15f),p);c.drawCircle(x-dp(9f),y,dp(10f),p);c.drawCircle(x+dp(9f),y,dp(10f),p)}
 private fun drawBuilding(c:Canvas,x:Float,y:Float,type:String){when(type){"HOUSE"->{p.color=Color.rgb(196,151,87);c.drawRect(x-dp(25f),y-dp(5f),x+dp(25f),y+dp(23f),p);val q=Path();q.moveTo(x-dp(31f),y-dp(5f));q.lineTo(x,y-dp(29f));q.lineTo(x+dp(31f),y-dp(5f));q.close();p.color=Color.rgb(123,62,44);c.drawPath(q,p);p.color=Color.rgb(70,48,34);c.drawRect(x-dp(6f),y+dp(8f),x+dp(6f),y+dp(23f),p)};"COOK"->{p.color=Color.rgb(158,113,66);c.drawRect(x-dp(19f),y-dp(14f),x+dp(19f),y+dp(14f),p);p.color=Color.rgb(58,48,40);c.drawCircle(x,y-dp(18f),dp(7f),p);label(c,x,y+dp(29f),"COOK")};"PURIFY"->{p.color=Color.rgb(83,137,165);c.drawRect(x-dp(19f),y-dp(14f),x+dp(19f),y+dp(14f),p);p.color=Color.WHITE;c.drawCircle(x,y,dp(7f),p);label(c,x,y+dp(29f),"PURIFY")}}}
 private fun label(c:Canvas,x:Float,y:Float,s:String){t.color=Color.WHITE;t.textSize=sp(8f);t.textAlign=Paint.Align.CENTER;c.drawText(s,x,y,t);t.textAlign=Paint.Align.LEFT}
 private fun drawCharacter(c:Canvas,x:Float,y:Float,u:CharacterUnit,player:Boolean){val bc=when(u.magic){"DARK"->Color.rgb(70,45,95);"WATER"->Color.rgb(45,125,190);"LIGHT"->Color.rgb(220,205,80);"FIRE"->Color.rgb(195,75,42);else->Color.DKGRAY};p.color=bc;c.drawRoundRect(x-dp(7f),y-dp(3f),x+dp(7f),y+dp(13f),dp(4f),dp(4f),p);p.color=Color.rgb(239,196,151);c.drawCircle(x,y-dp(10f),dp(6f),p);p.color=Color.DKGRAY;c.drawRect(x-dp(5f),y+dp(12f),x-dp(2f),y+dp(20f),p);c.drawRect(x+dp(2f),y+dp(12f),x+dp(5f),y+dp(20f),p);if(player){p.color=Color.WHITE;p.style=Paint.Style.STROKE;p.strokeWidth=dp(2f);c.drawCircle(x,y-dp(2f),dp(15f),p);p.style=Paint.Style.FILL}}
 private fun drawBeast(c:Canvas,x:Float,y:Float,b:MagicBeast){p.color=when(b.power){BeastPower.FIRE->Color.rgb(205,65,40);BeastPower.WATER->Color.rgb(45,125,205);BeastPower.LIGHTNING->Color.rgb(230,200,45);BeastPower.ICE->Color.rgb(105,210,225);BeastPower.DARK->Color.rgb(78,45,105);BeastPower.LIGHT->Color.rgb(245,225,120);BeastPower.NATURE->Color.rgb(55,145,65);BeastPower.EARTH->Color.rgb(120,91,62)};c.drawCircle(x,y,dp(13f),p);val q=Path();q.moveTo(x-dp(8f),y-dp(8f));q.lineTo(x-dp(15f),y-dp(21f));q.lineTo(x-dp(2f),y-dp(12f));q.close();c.drawPath(q,p);q.reset();q.moveTo(x+dp(8f),y-dp(8f));q.lineTo(x+dp(15f),y-dp(21f));q.lineTo(x+dp(2f),y-dp(12f));q.close();c.drawPath(q,p);p.color=Color.WHITE;c.drawCircle(x-dp(4f),y-dp(2f),dp(2f),p);c.drawCircle(x+dp(4f),y-dp(2f),dp(2f),p);p.color=Color.argb(180,0,0,0);c.drawRect(x-dp(14f),y-dp(29f),x+dp(14f),y-dp(25f),p);p.color=Color.rgb(220,70,70);val ratio=(b.hp.toFloat()/b.maxHp.toFloat()).coerceIn(0f,1f);c.drawRect(x-dp(14f),y-dp(29f),x-dp(14f)+dp(28f)*ratio,y-dp(25f),p);label(c,x,y+dp(25f),powerName(b.power))}
 private fun powerName(v:BeastPower)=when(v){BeastPower.FIRE->"FIRE";BeastPower.WATER->"WATER";BeastPower.LIGHTNING->"LIGHTNING";BeastPower.ICE->"ICE";BeastPower.DARK->"DARK";BeastPower.LIGHT->"HOLY";BeastPower.NATURE->"NATURE";BeastPower.EARTH->"EARTH"}
 private fun powerBonus(v:BeastPower)=when(v){BeastPower.FIRE->4;BeastPower.WATER->2;BeastPower.LIGHTNING->6;BeastPower.ICE->3;BeastPower.DARK->6;BeastPower.LIGHT->3;BeastPower.NATURE->2;BeastPower.EARTH->5}
 private fun button(c:Canvas,cx:Float,cy:Float,bw:Float,bh:Float,label:String){p.color=Color.argb(235,35,42,39);c.drawRoundRect(cx-bw/2,cy-bh/2,cx+bw/2,cy+bh/2,dp(10f),dp(10f),p);p.color=Color.WHITE;p.style=Paint.Style.STROKE;p.strokeWidth=dp(1.5f);c.drawRoundRect(cx-bw/2,cy-bh/2,cx+bw/2,cy+bh/2,dp(10f),dp(10f),p);p.style=Paint.Style.FILL;t.color=Color.WHITE;t.textSize=sp(11f);t.textAlign=Paint.Align.CENTER;c.drawText(label,cx,cy+sp(4f),t);t.textAlign=Paint.Align.LEFT}
 override fun onDetachedFromWindow(){saveGame();super.onDetachedFromWindow()}\n override fun onTouchEvent(e:MotionEvent):Boolean{if(e.action!=MotionEvent.ACTION_UP)return true;val x=e.x/width;val y=e.y/height;if(y>.895f&&x>=.62f&&x<.82f){attackMode=!attackMode;if(attackMode){villagers[0].attackTimer=0f;selectedBeast=nearestVisibleBeast(villagers[0].x,villagers[0].y);msg(if(selectedBeast>=0)"Dark Magic attack — team attack"else"Enter the forest to reveal a Beast")}else msg("Attack stopped");saveGame();return true};if(y>.895f&&x>=.82f){fast=!fast;msg(if(fast)"Fast time"else"Normal time");return true};if(y>.20f&&y<.89f){playerTargetX=x.coerceIn(.06f,.94f);playerTargetY=y.coerceIn(.25f,.86f);var closest=-1;var bestD=.04f;beasts.forEachIndexed{i,b->if(b.revealed){val d=dist(x,y,b.x,b.y);if(d<bestD){bestD=d;closest=i}}};if(closest>=0){selectedBeast=closest;attackMode=true;msg("Target selected — team attacks automatically")}};return true}
 private fun msg(s:String){toast=s;toastUntil=System.currentTimeMillis()+1800L};private fun dp(v:Float)=v*resources.displayMetrics.density;private fun sp(v:Float)=v*resources.displayMetrics.scaledDensity
}
