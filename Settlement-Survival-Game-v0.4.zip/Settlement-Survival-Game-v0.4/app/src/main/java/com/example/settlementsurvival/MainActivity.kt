package com.example.settlementsurvival

import android.app.Activity
import android.os.Bundle
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.view.*
import android.content.Context
import kotlin.math.*
import java.util.Random

class MainActivity : Activity() {
    private lateinit var gameView: GameView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setBackgroundDrawable(ColorDrawable(Color.rgb(70,125,78)))
        gameView = GameView(this)
        setContentView(gameView)
    }

    override fun onPause() {
        gameView.saveNow()
        super.onPause()
    }
}

enum class BeastPower { FIRE, WATER, LIGHTNING, ICE, DARK, LIGHT, NATURE, EARTH }
data class Tree(val x:Float,val y:Float)
data class Building(val x:Float,val y:Float,val type:String)
data class CharacterUnit(var x:Float,var y:Float,val name:String,val magic:String,var level:Int=1,var xp:Int=0,var attackTimer:Float=0f,var hp:Int=100,var maxHp:Int=100)
data class MagicBeast(var x:Float,var y:Float,val power:BeastPower,var hp:Int,val maxHp:Int,var tx:Float,var ty:Float,var wanderTimer:Float=0f,var attackTimer:Float=0f,var revealed:Boolean=false)

class GameView(context:Context):View(context){
 private val save=context.getSharedPreferences("settlement_survival_save",Context.MODE_PRIVATE)
 private val saveSchema=1
 private var saveTimer=0f
 private var quest=1
 private var questKills=0
 private val p=Paint(Paint.ANTI_ALIAS_FLAG); private val t=Paint(Paint.ANTI_ALIAS_FLAG)
 private val trees=mutableListOf<Tree>(); private val buildings=mutableListOf<Building>(); private val villagers=mutableListOf<CharacterUnit>(); private val beasts=mutableListOf<MagicBeast>()
 private val random=Random(404)
 private var wood=80; private var rawMeat=0; private var food=12; private var riverWater=0; private var cleanWater=60
 private var day=1; private var hour=8f; private var fast=false; private var last=System.currentTimeMillis()
 private var selectedBeast=-1; private var playerTargetX=.50f; private var playerTargetY=.56f; private var attackMode=false
 private var toast=""; private var toastUntil=0L
 init{
  t.typeface=Typeface.create("sans",Typeface.BOLD)
  repeat(42){trees+=Tree(.07f+random.nextFloat()*.23f,.29f+random.nextFloat()*.53f)}
  buildings+=Building(.50f,.52f,"HOUSE"); buildings+=Building(.42f,.61f,"COOK"); buildings+=Building(.58f,.61f,"PURIFY")
  villagers+=CharacterUnit(.50f,.55f,"PLAYER","DARK"); villagers+=CharacterUnit(.46f,.58f,"NPC1","WATER"); villagers+=CharacterUnit(.54f,.58f,"NPC2","LIGHT"); villagers+=CharacterUnit(.50f,.63f,"NPC3","FIRE")
  loadGame()
  spawnBeasts()
 }
 private fun spawnBeasts(){
  beasts.clear(); val powers=BeastPower.values(); repeat(8){i->val hp=35+i*3; val x=.10f+random.nextFloat()*.17f; val y=.33f+random.nextFloat()*.46f; beasts+=MagicBeast(x,y,powers[i%powers.size],hp,hp,x,y)}
 }

 fun saveNow(){saveGame()}

 private fun saveGame(){
  val e=save.edit()
  e.putInt("schema",saveSchema)
  e.putInt("day",day).putFloat("hour",hour)
   .putInt("wood",wood).putInt("rawMeat",rawMeat).putInt("food",food)
   .putInt("riverWater",riverWater).putInt("cleanWater",cleanWater)
   .putInt("quest",quest).putInt("questKills",questKills)
  villagers.forEachIndexed{i,u->
   e.putFloat("u${i}x",u.x).putFloat("u${i}y",u.y)
    .putInt("u${i}level",u.level).putInt("u${i}xp",u.xp)
    .putInt("u${i}hp",u.hp).putInt("u${i}maxHp",u.maxHp)
  }
  e.apply()
 }
 private fun loadGame(){
  if(!save.contains("day"))return
  day=save.getInt("day",1).coerceAtLeast(1)
  hour=save.getFloat("hour",8f).coerceIn(0f,23.99f)
  wood=save.getInt("wood",80).coerceAtLeast(0)
  rawMeat=save.getInt("rawMeat",0).coerceAtLeast(0)
  food=save.getInt("food",12).coerceAtLeast(0)
  riverWater=save.getInt("riverWater",0).coerceIn(0,100)
  cleanWater=save.getInt("cleanWater",60).coerceIn(0,100)
  quest=save.getInt("quest",1).coerceAtLeast(1)
  questKills=save.getInt("questKills",0).coerceAtLeast(0)
  villagers.forEachIndexed{i,u->
   u.x=save.getFloat("u${i}x",u.x).coerceIn(.08f,.92f)
   u.y=save.getFloat("u${i}y",u.y).coerceIn(.30f,.86f)
   u.level=save.getInt("u${i}level",1).coerceAtLeast(1)
   u.xp=save.getInt("u${i}xp",0).coerceAtLeast(0)
   u.maxHp=save.getInt("u${i}maxHp",100).coerceAtLeast(100)
   u.hp=save.getInt("u${i}hp",u.maxHp).coerceIn(1,u.maxHp)
  }
 }

 override fun onDraw(c:Canvas){val now=System.currentTimeMillis();val dt=((now-last).coerceAtMost(80L)/1000f)*(if(fast)2f else 1f);last=now;update(dt);drawGame(c);postInvalidateDelayed(33)}
 private fun update(dt:Float){
  hour+=dt*.50f
  if(hour>=24f){hour-=24f;day++;food=max(0,food-4);cleanWater=max(0,cleanWater-4);if(food==0)msg("Food is empty");if(cleanWater==0)msg("Clean water is empty")}
  if(hour>=7f&&hour<18f&&riverWater<100)riverWater=min(100,riverWater+1)
  if(rawMeat>0&&hour>=6f&&hour<20f){rawMeat--;food+=2}
  updatePlayer(dt);updateNpc(dt);updateBeasts(dt);resolveCombat(dt);cleanWater=min(100,cleanWater+if(riverWater>=10)1 else 0);if(riverWater>=10)riverWater--
  if(beasts.isEmpty()){spawnBeasts();msg("New Magic Beasts appeared in the forest")}
 }
 private fun updatePlayer(dt:Float){
  val u=villagers[0];val dx=playerTargetX-u.x;val dy=playerTargetY-u.y;val d=sqrt(dx*dx+dy*dy);if(d>.008f){u.x+=dx/d*dt*.060f;u.y+=dy/d*dt*.060f};u.x=u.x.coerceIn(.08f,.92f);u.y=u.y.coerceIn(.30f,.86f)
  if(u.x<.34f)beasts.forEach{it.revealed=true};if(selectedBeast in beasts.indices&&dist(u.x,u.y,beasts[selectedBeast].x,beasts[selectedBeast].y)<.30f)beasts[selectedBeast].revealed=true
  if(attackMode)selectedBeast=nearestVisibleBeast(u.x,u.y)
 }
 private fun updateNpc(dt:Float){
  val player=villagers[0]
  for(i in 1 until villagers.size){val n=villagers[i];val enemy=nearestVisibleBeast(n.x,n.y)
   if(enemy>=0){val b=beasts[enemy];val dx=b.x-n.x;val dy=b.y-n.y;val d=sqrt(dx*dx+dy*dy);if(d>.055f){n.x+=dx/d*dt*.045f;n.y+=dy/d*dt*.045f}}
   else{val ox=if(i==1)-.045f else if(i==2).045f else 0f;val tx=player.x+ox;val ty=player.y+.055f;val dx=tx-n.x;val dy=ty-n.y;val d=sqrt(dx*dx+dy*dy);if(d>.012f){n.x+=dx/d*dt*.035f;n.y+=dy/d*dt*.035f}}
   n.x=n.x.coerceIn(.08f,.92f);n.y=n.y.coerceIn(.30f,.86f)
  }
 }
 private fun updateBeasts(dt:Float){beasts.forEach{b->b.wanderTimer-=dt;if(b.wanderTimer<=0f){val a=random.nextDouble()*Math.PI*2;b.tx=(b.x+cos(a).toFloat()*.07f).coerceIn(.08f,.31f);b.ty=(b.y+sin(a).toFloat()*.07f).coerceIn(.30f,.84f);b.wanderTimer=1.5f+random.nextFloat()*2.5f;if(random.nextFloat()<.12f){b.revealed=true;b.tx=.40f+random.nextFloat()*.20f;b.ty=.48f+random.nextFloat()*.20f}};val dx=b.tx-b.x;val dy=b.ty-b.y;val d=sqrt(dx*dx+dy*dy);if(d>.006f){b.x+=dx/d*dt*.018f;b.y+=dy/d*dt*.018f};if(b.x<.33f&&dist(b.x,b.y,villagers[0].x,villagers[0].y)>.28f&&random.nextFloat()<.01f*dt)b.revealed=false}}
 private fun resolveCombat(dt:Float){if(beasts.isEmpty())return
  if(attackMode){val target=nearestVisibleBeast(villagers[0].x,villagers[0].y);if(target>=0){selectedBeast=target;val b=beasts[target];villagers.forEach{u->u.attackTimer-=dt;if(u.attackTimer<=0f&&dist(u.x,u.y,b.x,b.y)<.18f){val damage=when(u.magic){
       "DARK"->12+u.level*3
       "WATER"->8+u.level*2
       "LIGHT"->9+u.level*2
       "FIRE"->11+u.level*3
       else->7
      }
      val special=when(b.power){
       BeastPower.FIRE->if(u.magic=="WATER")2 else 0
       BeastPower.WATER->if(u.magic=="FIRE")-2 else 0
       BeastPower.LIGHTNING->if(u.magic=="WATER")-2 else 0
       BeastPower.ICE->if(u.magic=="FIRE")2 else 0
       BeastPower.DARK->if(u.magic=="LIGHT")2 else 0
       BeastPower.LIGHT->if(u.magic=="DARK")2 else 0
       BeastPower.NATURE->if(u.magic=="FIRE")2 else 0
       BeastPower.EARTH->if(u.magic=="WATER")1 else 0
      }
      b.hp-=max(1,damage+special);u.attackTimer=.65f;gainXp(u,10)}}}}
  beasts.forEach{b->val near=villagers.minByOrNull{u->dist(u.x,u.y,b.x,b.y)};if(near!=null&&dist(near.x,near.y,b.x,b.y)<.15f){b.attackTimer-=dt;if(b.attackTimer<=0f){near.hp-=4+powerBonus(b.power);b.attackTimer=1.1f;attackMode=true;selectedBeast=beasts.indexOf(b);msg("${powerName(b.power)} Beast attacks — team defending")}}}
  val dead=beasts.filter{it.hp<=0};if(dead.isNotEmpty()){dead.forEach{rawMeat+=2;questKills++;villagers.forEach{u->gainXp(u,15)}}
   if(questKills>=quest*3){quest++;questKills=0;wood+=10;food+=4;msg("RPG Quest complete! Reward +10 wood +4 food")}
   beasts.removeAll(dead.toSet());selectedBeast=-1;attackMode=false;msg("+${dead.size*2} monster meat")}
  villagers.forEach{it.hp=it.hp.coerceIn(0,it.maxHp);if(it.hp==0){it.hp=it.maxHp;msg("${it.name} recovered at the settlement")}}
 }
 private fun gainXp(u:CharacterUnit,amount:Int){
  u.xp+=amount
  while(u.xp>=u.level*50){
   u.xp-=u.level*50
   u.level++
   u.maxHp+=10
   u.hp=u.maxHp
   msg("${u.name} reached Level ${u.level} — new ability unlocked")
  }
 }
 private fun nearestVisibleBeast(x:Float,y:Float):Int{var best=-1;var bestD=Float.MAX_VALUE;beasts.forEachIndexed{i,b->if(b.revealed){val d=dist(x,y,b.x,b.y);if(d<bestD){bestD=d;best=i}}};return best}
 private fun dist(x1:Float,y1:Float,x2:Float,y2:Float)=sqrt((x2-x1).pow(2)+(y2-y1).pow(2))
  private fun drawGame(c:Canvas){
   val w=width.toFloat(); val h=height.toFloat(); val night=hour<6f||hour>=19f
   drawSkyAndMeadow(c,w,h,night)
   drawForest(c,w,h,night)
   drawRiver(c,w,h)
   drawSettlement(c,w,h)
   drawCharactersAndBeasts(c,w,h)
   drawHud(c,w,h)
  }
  private fun drawSkyAndMeadow(c:Canvas,w:Float,h:Float,night:Boolean){
   p.shader=LinearGradient(0f,h*.18f,w,h*.90f,if(night)Color.rgb(35,78,45)else Color.rgb(117,184,92),if(night)Color.rgb(52,103,57)else Color.rgb(91,163,82),Shader.TileMode.CLAMP);c.drawRect(0f,h*.18f,w,h,p);p.shader=null
   p.color=Color.argb(220,18,29,24);c.drawRect(0f,0f,w,h*.18f,p)
   t.color=Color.WHITE;t.textSize=sp(19f);c.drawText("SETTLEMENT SURVIVAL  v0.4",dp(14f),dp(25f),t);t.textSize=sp(11f);t.color=Color.rgb(214,225,216);c.drawText("Day $day • ${hour.toInt().toString().padStart(2,'0')}:${((hour%1f)*60).toInt().toString().padStart(2,'0')}",dp(16f),dp(45f),t)
   p.color=Color.argb(if(night)30 else 48,255,255,255);repeat(80){i->val x=dp(8f)+((i*83)%max(1,width)).toFloat();val y=h*.22f+((i*47)%(max(1,(h*.64f).toInt()))).toFloat();c.drawCircle(x,y,dp(if(i%3==0)1.3f else .8f),p)}
  }
  private fun drawForest(c:Canvas,w:Float,h:Float,night:Boolean){
   val left=w*.04f;val top=h*.20f;val bottom=h*.88f;p.shader=LinearGradient(left,top,w*.33f,bottom,if(night)Color.rgb(18,61,31)else Color.rgb(27,105,49),if(night)Color.rgb(26,82,39)else Color.rgb(48,133,57),Shader.TileMode.CLAMP);c.drawRoundRect(left,top,w*.31f,bottom,dp(18f),dp(18f),p);p.shader=null
   repeat(34){i->val x=w*(.055f+(i%7)*.037f+((i*17)%9)*.001f);val y=h*(.27f+(i/7)*.13f+((i*11)%8)*.002f);drawPine(c,x,y,dp(15f+(i%3)*3f),night)}
   beasts.filter{it.revealed&&it.x<.34f}.forEach{drawBeastGlow(c,w*it.x,h*it.y,it)}
  }
  private fun drawPine(c:Canvas,x:Float,y:Float,size:Float,night:Boolean){
   p.color=Color.rgb(83,57,38);c.drawRoundRect(x-size*.10f,y-size*.02f,x+size*.10f,y+size*.72f,size*.08f,size*.08f,p);p.color=if(night)Color.rgb(19,73,34)else Color.rgb(25,119,49);val q=Path();q.moveTo(x,y-size*.95f);q.lineTo(x-size*.72f,y+size*.05f);q.lineTo(x-size*.34f,y+size*.02f);q.lineTo(x-size*.86f,y+size*.48f);q.lineTo(x+size*.86f,y+size*.48f);q.lineTo(x+size*.34f,y+size*.02f);q.close();c.drawPath(q,p);p.color=Color.argb(35,255,255,255);c.drawCircle(x-size*.22f,y-size*.40f,size*.13f,p)
  }
  private fun drawRiver(c:Canvas,w:Float,h:Float){
   val top=h*.20f;val bottom=h*.88f;val bank=Path();bank.moveTo(w*.78f,top);bank.cubicTo(w*.68f,h*.33f,w*.90f,h*.48f,w*.80f,h*.63f);bank.cubicTo(w*.74f,h*.73f,w*.87f,h*.80f,w*.79f,bottom);bank.lineTo(w*.96f,bottom);bank.lineTo(w*.96f,top);bank.close();p.color=Color.rgb(202,183,126);c.drawPath(bank,p)
   val water=Path();water.moveTo(w*.81f,top);water.cubicTo(w*.73f,h*.34f,w*.91f,h*.49f,w*.83f,h*.62f);water.cubicTo(w*.78f,h*.72f,w*.90f,h*.80f,w*.82f,bottom);water.lineTo(w*.96f,bottom);water.lineTo(w*.96f,top);water.close();p.shader=LinearGradient(w*.78f,top,w*.95f,bottom,Color.rgb(42,150,209),Color.rgb(40,112,177),Shader.TileMode.CLAMP);c.drawPath(water,p);p.shader=null;p.color=Color.argb(90,255,255,255);repeat(9){i->val y=h*(.24f+i*.071f);c.drawRoundRect(w*.84f,y,w*.93f,y+dp(2f),dp(2f),dp(2f),p)}
  }
  private fun drawSettlement(c:Canvas,w:Float,h:Float){
   val fx=w*.50f;val fy=h*.55f;val fr=min(w,h)*.18f;p.setShadowLayer(dp(10f),0f,dp(5f),Color.argb(90,0,0,0));p.color=Color.argb(35,255,255,255);c.drawCircle(fx,fy,fr+dp(6f),p);p.clearShadowLayer();p.color=Color.rgb(106,75,43);p.style=Paint.Style.STROKE;p.strokeWidth=dp(9f);c.drawCircle(fx,fy,fr,p);p.color=Color.rgb(169,118,62);p.strokeWidth=dp(3f);c.drawCircle(fx,fy,fr,p);p.style=Paint.Style.FILL
   for(a in 0 until 28){val ang=a*PI/14.0;val x=(fx+cos(ang)*fr).toFloat();val y=(fy+sin(ang)*fr).toFloat();p.color=Color.rgb(129,88,48);c.save();c.rotate(a*180f/14f+90f,x,y);c.drawRoundRect(x-dp(3f),y-dp(11f),x+dp(3f),y+dp(2f),dp(2f),dp(2f),p);c.restore()}
   p.color=Color.rgb(201,166,111);c.drawRoundRect(fx-dp(12f),fy+fr-dp(3f),fx+dp(12f),fy+fr+dp(58f),dp(8f),dp(8f),p);drawGate(c,fx,fy+fr+dp(4f));drawHouse(c,fx,fy-dp(34f));drawCookHouse(c,fx-dp(73f),fy+dp(42f));drawPurifyHouse(c,fx+dp(73f),fy+dp(42f))
  }
  private fun drawGate(c:Canvas,x:Float,y:Float){p.color=Color.rgb(83,57,38);c.drawRoundRect(x-dp(27f),y-dp(8f),x+dp(27f),y+dp(9f),dp(4f),dp(4f),p);p.color=Color.rgb(151,103,52);p.style=Paint.Style.STROKE;p.strokeWidth=dp(3f);c.drawRect(x-dp(25f),y-dp(7f),x+dp(25f),y+dp(8f),p);c.drawLine(x-dp(20f),y-dp(5f),x+dp(20f),y+dp(6f),p);c.drawLine(x+dp(20f),y-dp(5f),x-dp(20f),y+dp(6f),p);p.style=Paint.Style.FILL}
  private fun buildingShadow(c:Canvas,x:Float,y:Float,wid:Float,hei:Float){p.color=Color.argb(65,0,0,0);c.drawOval(x-wid/2,y+hei*.30f,x+wid/2,y+hei*.58f,p)}
  private fun drawHouse(c:Canvas,x:Float,y:Float){buildingShadow(c,x,y,dp(92f),dp(48f));p.setShadowLayer(dp(7f),0f,dp(4f),Color.argb(90,0,0,0));p.color=Color.rgb(238,205,151);c.drawRoundRect(x-dp(37f),y-dp(5f),x+dp(37f),y+dp(35f),dp(4f),dp(4f),p);p.clearShadowLayer();val roof=Path();roof.moveTo(x-dp(46f),y-dp(5f));roof.lineTo(x,y-dp(39f));roof.lineTo(x+dp(46f),y-dp(5f));roof.close();p.color=Color.rgb(176,70,48);c.drawPath(roof,p);p.color=Color.rgb(126,52,38);c.drawRect(x-dp(5f),y+dp(15f),x+dp(5f),y+dp(35f),p);p.color=Color.rgb(81,151,184);c.drawRoundRect(x-dp(28f),y+dp(6f),x-dp(14f),y+dp(19f),dp(2f),dp(2f),p);c.drawRoundRect(x+dp(14f),y+dp(6f),x+dp(28f),y+dp(19f),dp(2f),dp(2f),p);label(c,x,y+dp(50f),"MAIN HOUSE")}
  private fun drawCookHouse(c:Canvas,x:Float,y:Float){buildingShadow(c,x,y,dp(64f),dp(38f));p.color=Color.rgb(180,125,69);c.drawRoundRect(x-dp(28f),y-dp(11f),x+dp(28f),y+dp(20f),dp(4f),dp(4f),p);val roof=Path();roof.moveTo(x-dp(32f),y-dp(11f));roof.lineTo(x,y-dp(30f));roof.lineTo(x+dp(32f),y-dp(11f));roof.close();p.color=Color.rgb(126,69,42);c.drawPath(roof,p);p.color=Color.rgb(75,53,39);c.drawCircle(x+dp(18f),y-dp(26f),dp(6f),p);p.color=Color.argb(65,255,255,255);c.drawCircle(x+dp(18f),y-dp(34f),dp(5f),p);label(c,x,y+dp(35f),"COOK")}
  private fun drawPurifyHouse(c:Canvas,x:Float,y:Float){buildingShadow(c,x,y,dp(64f),dp(38f));p.color=Color.rgb(82,137,169);c.drawRoundRect(x-dp(28f),y-dp(11f),x+dp(28f),y+dp(20f),dp(4f),dp(4f),p);val roof=Path();roof.moveTo(x-dp(32f),y-dp(11f));roof.lineTo(x,y-dp(29f));roof.lineTo(x+dp(32f),y-dp(11f));roof.close();p.color=Color.rgb(54,94,117);c.drawPath(roof,p);p.color=Color.rgb(80,193,220);c.drawCircle(x,y+dp(3f),dp(9f),p);p.color=Color.WHITE;c.drawCircle(x,y+dp(3f),dp(3f),p);label(c,x,y+dp(35f),"PURIFY")}
  private fun drawCharactersAndBeasts(c:Canvas,w:Float,h:Float){beasts.filter{it.revealed}.forEach{drawBeast(c,w*it.x,h*it.y,it)};villagers.forEachIndexed{i,u->drawCharacter(c,w*u.x,h*u.y,u,i==0)};if(selectedBeast in beasts.indices&&beasts[selectedBeast].revealed){val b=beasts[selectedBeast];p.color=Color.WHITE;p.style=Paint.Style.STROKE;p.strokeWidth=dp(2f);c.drawCircle(w*b.x,h*b.y,dp(23f),p);p.style=Paint.Style.FILL}}
  private fun drawBeastGlow(c:Canvas,x:Float,y:Float,b:MagicBeast){p.color=Color.argb(45,255,70,70);c.drawCircle(x,y,dp(24f),p);drawBeast(c,x,y,b)}
  private fun drawHud(c:Canvas,w:Float,h:Float){val xs=floatArrayOf(.08f,.21f,.34f,.47f,.60f,.73f,.86f);val vals=arrayOf("4","$food","$rawMeat","$cleanWater","$riverWater","$wood","${beasts.count{it.revealed}}");val labels=arrayOf("TEAM","FOOD","MEAT","CLEAN","RIVER","WOOD","BEASTS");for(i in xs.indices)stat(c,xs[i],vals[i],labels[i]);p.color=Color.argb(220,14,25,20);c.drawRoundRect(w*.03f,h*.76f,w*.42f,h*.875f,dp(12f),dp(12f),p);t.color=Color.WHITE;t.textSize=sp(9f);c.drawText("RPG QUEST $quest  •  ${questKills}/${quest*3} BEAST KILLS",w*.055f,h*.785f,t);t.textSize=sp(9f);villagers.forEachIndexed{i,u->{val ability=when(u.magic){"DARK"->when(u.level){1->"Dark Bolt";2->"Shadow Dash";3->"Dark Shield";4->"Life Drain";else->"Shadow Blast"};"WATER"->when(u.level){1->"Water Bolt";2->"Healing Wave";3->"Water Shield";4->"Ice Trap";else->"Tidal Blast"};"LIGHT"->when(u.level){1->"Light Beam";2->"Heal";3->"Holy Shield";4->"Flash";else->"Light Aura"};"FIRE"->when(u.level){1->"Fire Bolt";2->"Fire Wall";3->"Flame Burst";4->"Fire Storm";else->"Burning Mark"};else->"Basic"};c.drawText("${u.name}  ${u.magic}  Lv${u.level}  XP${u.xp}  • $ability",w*.055f,h*.808f+i*dp(15f),t)}};button(c,w*.70f,h*.93f,w*.20f,h*.07f,if(attackMode)"ATTACKING"else"ATTACK");button(c,w*.89f,h*.93f,w*.11f,h*.07f,if(fast)"≫" else ">");if(System.currentTimeMillis()<toastUntil){p.color=Color.argb(225,0,0,0);c.drawRoundRect(w*.23f,h*.20f,w*.77f,h*.265f,dp(10f),dp(10f),p);t.color=Color.WHITE;t.textSize=sp(11f);t.textAlign=Paint.Align.CENTER;c.drawText(toast,w*.50f,h*.242f,t);t.textAlign=Paint.Align.LEFT)}}
  private fun stat(c:Canvas,x:Float,value:String,label:String){t.color=Color.WHITE;t.textSize=sp(13f);t.textAlign=Paint.Align.CENTER;c.drawText(value,width*x,dp(70f),t);t.color=Color.LTGRAY;t.textSize=sp(7.5f);c.drawText(label,width*x,dp(82f),t);t.textAlign=Paint.Align.LEFT}
  private fun drawCharacter(c:Canvas,x:Float,y:Float,u:CharacterUnit,player:Boolean){p.setShadowLayer(dp(5f),0f,dp(3f),Color.argb(90,0,0,0));val bc=when(u.magic){"DARK"->Color.rgb(73,45,108);"WATER"->Color.rgb(47,131,191);"LIGHT"->Color.rgb(229,204,76);"FIRE"->Color.rgb(204,76,45);else->Color.DKGRAY};p.color=bc;c.drawRoundRect(x-dp(9f),y-dp(2f),x+dp(9f),y+dp(17f),dp(5f),dp(5f),p);p.clearShadowLayer();p.color=Color.rgb(239,196,151);c.drawCircle(x,y-dp(10f),dp(7f),p);p.color=Color.rgb(53,42,35);c.drawRoundRect(x-dp(6f),y-dp(17f),x+dp(6f),y-dp(11f),dp(3f),dp(3f),p);p.color=Color.DKGRAY;c.drawRect(x-dp(6f),y+dp(17f),x-dp(2f),y+dp(26f),p);c.drawRect(x+dp(2f),y+dp(17f),x+dp(6f),y+dp(26f),p);p.color=Color.argb(70,100,70,170);c.drawCircle(x,y-dp(3f),dp(16f),p);if(player){p.color=Color.WHITE;p.style=Paint.Style.STROKE;p.strokeWidth=dp(2f);c.drawCircle(x,y-dp(3f),dp(18f),p);p.style=Paint.Style.FILL}label(c,x,y+dp(37f),u.name)}
  private fun drawBeast(c:Canvas,x:Float,y:Float,b:MagicBeast){val base=when(b.power){BeastPower.FIRE->Color.rgb(215,67,40);BeastPower.WATER->Color.rgb(45,132,210);BeastPower.LIGHTNING->Color.rgb(238,205,44);BeastPower.ICE->Color.rgb(102,211,227);BeastPower.DARK->Color.rgb(82,47,116);BeastPower.LIGHT->Color.rgb(246,225,122);BeastPower.NATURE->Color.rgb(57,153,70);BeastPower.EARTH->Color.rgb(126,92,61)};p.setShadowLayer(dp(6f),0f,dp(3f),Color.argb(100,0,0,0));p.color=base;c.drawCircle(x,y,dp(14f),p);p.clearShadowLayer();val q=Path();q.moveTo(x-dp(8f),y-dp(8f));q.lineTo(x-dp(16f),y-dp(23f));q.lineTo(x-dp(2f),y-dp(13f));q.close();c.drawPath(q,p);q.reset();q.moveTo(x+dp(8f),y-dp(8f));q.lineTo(x+dp(16f),y-dp(23f));q.lineTo(x+dp(2f),y-dp(13f));q.close();c.drawPath(q,p);p.color=Color.WHITE;c.drawCircle(x-dp(4f),y-dp(2f),dp(2.2f),p);c.drawCircle(x+dp(4f),y-dp(2f),dp(2.2f),p);p.color=Color.argb(190,10,10,10);c.drawRoundRect(x-dp(16f),y-dp(31f),x+dp(16f),y-dp(26f),dp(3f),dp(3f),p);p.color=Color.rgb(222,70,70);val ratio=(b.hp.toFloat()/b.maxHp.toFloat()).coerceIn(0f,1f);c.drawRoundRect(x-dp(16f),y-dp(31f),x-dp(16f)+dp(32f)*ratio,y-dp(26f),dp(3f),dp(3f),p);label(c,x,y+dp(27f),powerName(b.power))}
  private fun label(c:Canvas,x:Float,y:Float,s:String){t.color=Color.WHITE;t.textSize=sp(8f);t.textAlign=Paint.Align.CENTER;c.drawText(s,x,y,t);t.textAlign=Paint.Align.LEFT}
  private fun button(c:Canvas,cx:Float,cy:Float,bw:Float,bh:Float,label:String){p.setShadowLayer(dp(5f),0f,dp(3f),Color.argb(100,0,0,0));p.color=Color.argb(235,24,35,30);c.drawRoundRect(cx-bw/2,cy-bh/2,cx+bw/2,cy+bh/2,dp(13f),dp(13f),p);p.clearShadowLayer();p.color=Color.WHITE;p.style=Paint.Style.STROKE;p.strokeWidth=dp(1.8f);c.drawRoundRect(cx-bw/2,cy-bh/2,cx+bw/2,cy+bh/2,dp(13f),dp(13f),p);p.style=Paint.Style.FILL;t.color=Color.WHITE;t.textSize=sp(11f);t.textAlign=Paint.Align.CENTER;c.drawText(label,cx,cy+sp(4f),t);t.textAlign=Paint.Align.LEFT}
 override fun onDetachedFromWindow(){
   saveGame()
   super.onDetachedFromWindow()
  }

  override fun onTouchEvent(e:MotionEvent):Boolean{if(e.action!=MotionEvent.ACTION_UP)return true;val x=e.x/width;val y=e.y/height;if(y>.895f&&x>=.62f&&x<.82f){attackMode=!attackMode;if(attackMode){villagers[0].attackTimer=0f;selectedBeast=nearestVisibleBeast(villagers[0].x,villagers[0].y);msg(if(selectedBeast>=0)"Dark Magic attack — team attack"else"Enter the forest to reveal a Beast")}else msg("Attack stopped");saveGame();return true};if(y>.895f&&x>=.82f){fast=!fast;msg(if(fast)"Fast time"else"Normal time");return true};if(y>.20f&&y<.89f){playerTargetX=x.coerceIn(.06f,.94f);playerTargetY=y.coerceIn(.25f,.86f);var closest=-1;var bestD=.04f;beasts.forEachIndexed{i,b->if(b.revealed){val d=dist(x,y,b.x,b.y);if(d<bestD){bestD=d;closest=i}}};if(closest>=0){selectedBeast=closest;attackMode=true;msg("Target selected — team attacks automatically")}};return true}
 private fun msg(s:String){toast=s;toastUntil=System.currentTimeMillis()+1800L};private fun dp(v:Float)=v*resources.displayMetrics.density;private fun sp(v:Float)=v*resources.displayMetrics.scaledDensity
}
