package com.example.settlementsurvival

import android.app.Activity
import android.os.Bundle
import android.graphics.*
import android.view.*
import android.content.Context
import kotlin.math.*
import kotlin.random.Random

class MainActivity : Activity() {
    private lateinit var game: GameView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        game = GameView(this)
        setContentView(game)
    }
    override fun onPause() {
        game.saveGame()
        super.onPause()
    }
}

private enum class MagicPower { FIRE, WATER, LIGHTNING, ICE, DARK, LIGHT, NATURE, EARTH }

private data class Unit(
    val name: String,
    val power: MagicPower,
    var x: Float,
    var y: Float,
    var level: Int = 1,
    var xp: Int = 0,
    var hp: Int = 100
) {
    fun maxHp() = 100 + (level - 1) * 20
    fun damage() = 12 + (level - 1) * 5
    fun addXp(v: Int): Boolean {
        xp += v
        var leveled = false
        while (xp >= level * 20) {
            xp -= level * 20
            level++
            hp = maxHp()
            leveled = true
        }
        return leveled
    }
}

private data class Beast(
    val power: MagicPower,
    var x: Float,
    var y: Float,
    var hp: Int = 60
)

private class GameView(ctx: Context) : View(ctx) {
    private val prefs = ctx.getSharedPreferences("settlement_survival_save", Context.MODE_PRIVATE)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val mapBitmap = BitmapFactory.decodeResource(resources, R.drawable.map_view)
    private val rng = Random(System.currentTimeMillis())

    private val player = Unit("Player", MagicPower.DARK, 620f, 420f)
    private val npc1 = Unit("Water", MagicPower.WATER, 570f, 455f)
    private val npc2 = Unit("Light", MagicPower.LIGHT, 650f, 455f)
    private val npc3 = Unit("Fire", MagicPower.FIRE, 610f, 490f)
    private val team = listOf(player, npc1, npc2, npc3)

    private val beasts = mutableListOf<Beast>()
    private var selected: Beast? = null
    private var attacking = false
    private var day = 1
    private var hour = 6
    private var minute = 0
    private var wood = 20
    private var food = 20
    private var water = 40
    private var cleanWater = 20
    private var meat = 0
    private var quest = 1
    private var questKills = 0
    private var lastTick = System.currentTimeMillis()
    private var lastSave = 0L

    init {
        loadGame()
        spawnBeasts()
        isFocusable = true
    }

    fun saveGame() {
        val e = prefs.edit()
        e.putInt("schema", 4)
        e.putInt("day", day)
        e.putInt("hour", hour)
        e.putInt("minute", minute)
        e.putInt("wood", wood)
        e.putInt("food", food)
        e.putInt("water", water)
        e.putInt("cleanWater", cleanWater)
        e.putInt("meat", meat)
        e.putInt("quest", quest)
        e.putInt("questKills", questKills)
        team.forEachIndexed { i, u ->
            e.putFloat("x$i", u.x)
            e.putFloat("y$i", u.y)
            e.putInt("lv$i", u.level)
            e.putInt("xp$i", u.xp)
            e.putInt("hp$i", u.hp)
        }
        e.apply()
    }

    private fun loadGame() {
        day = prefs.getInt("day", day)
        hour = prefs.getInt("hour", hour)
        minute = prefs.getInt("minute", minute)
        wood = prefs.getInt("wood", wood)
        food = prefs.getInt("food", food)
        water = prefs.getInt("water", water)
        cleanWater = prefs.getInt("cleanWater", cleanWater)
        meat = prefs.getInt("meat", meat)
        quest = prefs.getInt("quest", quest)
        questKills = prefs.getInt("questKills", questKills)
        team.forEachIndexed { i, u ->
            u.x = prefs.getFloat("x$i", u.x)
            u.y = prefs.getFloat("y$i", u.y)
            u.level = prefs.getInt("lv$i", u.level)
            u.xp = prefs.getInt("xp$i", u.xp)
            u.hp = prefs.getInt("hp$i", u.hp).coerceIn(1, u.maxHp())
        }
    }

    private fun spawnBeasts() {
        beasts.clear()
        val powers = MagicPower.values()
        repeat(8) { i ->
            val a = 0.35f + i * 0.30f
            beasts += Beast(
                powers[i % powers.size],
                120f + rng.nextFloat() * 350f,
                160f + rng.nextFloat() * 300f
            )
        }
    }

    private fun powerName(p: MagicPower): String = when (p) {
        MagicPower.FIRE -> "Fire"
        MagicPower.WATER -> "Water"
        MagicPower.LIGHTNING -> "Lightning"
        MagicPower.ICE -> "Ice"
        MagicPower.DARK -> "Dark"
        MagicPower.LIGHT -> "Light"
        MagicPower.NATURE -> "Nature"
        MagicPower.EARTH -> "Earth"
    }

    private fun powerBonus(p: MagicPower): Int = when (p) {
        MagicPower.FIRE -> 5
        MagicPower.WATER -> 3
        MagicPower.LIGHTNING -> 8
        MagicPower.ICE -> 4
        MagicPower.DARK -> 7
        MagicPower.LIGHT -> 4
        MagicPower.NATURE -> 3
        MagicPower.EARTH -> 6
    }

    private fun advanceTime() {
        minute += 5
        if (minute >= 60) {
            minute = 0
            hour++
        }
        if (hour >= 24) {
            hour = 0
            day++
        }
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w = width.toFloat()
        val h = height.toFloat()

        // New v0.4 map: the game opens directly on the illustrated map.
        c.drawColor(Color.rgb(20, 35, 25))
        paint.style = Paint.Style.FILL
        val src = Rect(0, 0, mapBitmap.width, mapBitmap.height)
        val dst = RectF(0f, 0f, w, h)
        c.drawBitmap(mapBitmap, src, dst, paint)

        // Dynamic gameplay layer: beasts remain interactive and move/attack on top of the map.
        drawBeasts(c)
        drawHud(c, w, h)

        val now = System.currentTimeMillis()
        if (now - lastTick > 1500) {
            advanceTime()
            lastTick = now
            if (now - lastSave > 2000) {
                saveGame()
                lastSave = now
            }
            invalidate()
        }
    }

    private fun drawForest(c: Canvas) {
        paint.color = Color.rgb(18, 72, 36)
        c.drawRect(55f, 135f, 390f, height - 95f, paint)
        for (i in 0 until 28) {
            val x = 75f + (i * 73f) % 295f
            val y = 160f + (i * 97f) % (height - 300f).coerceAtLeast(100f)
            paint.color = Color.rgb(12, 54, 28)
            c.drawCircle(x, y, 28f, paint)
            paint.color = Color.rgb(30, 94, 43)
            c.drawCircle(x - 8, y - 8, 20f, paint)
            paint.color = Color.rgb(101, 65, 35)
            c.drawRect(x - 4, y + 15, x + 4, y + 32, paint)
        }
        paint.color = Color.WHITE
        paint.textSize = 18f
        c.drawText("MAGIC FOREST", 80f, 160f, paint)
    }

    private fun drawRiver(c: Canvas, w: Float) {
        paint.color = Color.rgb(38, 105, 155)
        val path = Path()
        path.moveTo(w - 210f, 130f)
        path.cubicTo(w - 280f, 250f, w - 100f, 320f, w - 215f, height - 90f)
        path.lineTo(w - 45f, height - 90f)
        path.lineTo(w - 45f, 130f)
        path.close()
        c.drawPath(path, paint)
        paint.color = Color.rgb(93, 174, 210)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 5f
        c.drawLine(w - 150f, 170f, w - 155f, 260f, paint)
        c.drawLine(w - 130f, 350f, w - 145f, 500f, paint)
        paint.style = Paint.Style.FILL
        paint.color = Color.WHITE
        paint.textSize = 18f
        c.drawText("RIVER", w - 150f, 155f, paint)
    }

    private fun drawSettlement(c: Canvas) {
        val cx = 620f
        val cy = 390f
        paint.color = Color.rgb(92, 75, 50)
        c.drawCircle(cx, cy, 135f, paint)
        paint.color = Color.rgb(153, 103, 54)
        c.drawCircle(cx, cy, 122f, paint)
        paint.color = Color.rgb(49, 112, 61)
        c.drawCircle(cx, cy, 109f, paint)

        // Main house
        paint.color = Color.rgb(226, 180, 108)
        c.drawRect(cx - 55f, cy - 45f, cx + 55f, cy + 45f, paint)
        paint.color = Color.rgb(145, 65, 43)
        val roof = Path()
        roof.moveTo(cx - 70f, cy - 45f)
        roof.lineTo(cx, cy - 105f)
        roof.lineTo(cx + 70f, cy - 45f)
        roof.close()
        c.drawPath(roof, paint)
        paint.color = Color.rgb(70, 45, 30)
        c.drawRect(cx - 12f, cy + 5f, cx + 12f, cy + 45f, paint)

        drawBuilding(c, cx - 145f, cy + 35f, "COOK", Color.rgb(165, 104, 58))
        drawBuilding(c, cx + 145f, cy + 35f, "PURIFY", Color.rgb(69, 133, 170))
    }

    private fun drawBuilding(c: Canvas, x: Float, y: Float, label: String, color: Int) {
        paint.color = color
        c.drawRoundRect(x - 34f, y - 25f, x + 34f, y + 25f, 8f, 8f, paint)
        paint.color = Color.WHITE
        paint.textSize = 15f
        paint.textAlign = Paint.Align.CENTER
        c.drawText(label, x, y + 5f, paint)
        paint.textAlign = Paint.Align.LEFT
    }

    private fun drawCharacters(c: Canvas) {
        team.forEachIndexed { i, u ->
            val color = when (u.power) {
                MagicPower.DARK -> Color.rgb(75, 40, 115)
                MagicPower.WATER -> Color.rgb(55, 140, 205)
                MagicPower.LIGHT -> Color.rgb(240, 220, 100)
                MagicPower.FIRE -> Color.rgb(210, 70, 45)
                else -> Color.GRAY
            }
            paint.color = Color.rgb(245, 201, 140)
            c.drawCircle(u.x, u.y - 18f, 13f, paint)
            paint.color = color
            c.drawRoundRect(u.x - 14f, u.y - 5f, u.x + 14f, u.y + 25f, 7f, 7f, paint)
            paint.color = Color.WHITE
            paint.textSize = 12f
            c.drawText("${u.name} Lv${u.level}", u.x - 32f, u.y + 43f, paint)
        }
    }

    private fun drawBeasts(c: Canvas) {
        beasts.forEach { b ->
            val visible = hypot(b.x - player.x, b.y - player.y) < 240f || attacking
            if (!visible) return@forEach
            paint.color = when (b.power) {
                MagicPower.FIRE -> Color.rgb(230, 75, 35)
                MagicPower.WATER -> Color.rgb(45, 135, 210)
                MagicPower.LIGHTNING -> Color.rgb(235, 210, 60)
                MagicPower.ICE -> Color.rgb(120, 210, 235)
                MagicPower.DARK -> Color.rgb(90, 45, 130)
                MagicPower.LIGHT -> Color.rgb(245, 240, 150)
                MagicPower.NATURE -> Color.rgb(50, 155, 65)
                MagicPower.EARTH -> Color.rgb(130, 95, 60)
            }
            c.drawCircle(b.x, b.y, 18f, paint)
            paint.color = Color.BLACK
            c.drawCircle(b.x - 6f, b.y - 3f, 3f, paint)
            c.drawCircle(b.x + 6f, b.y - 3f, 3f, paint)
            paint.color = Color.WHITE
            paint.textSize = 11f
            c.drawText(powerName(b.power), b.x - 28f, b.y + 33f, paint)
        }
    }

    private fun drawHud(c: Canvas, w: Float, h: Float) {
        paint.color = Color.WHITE
        paint.textSize = 30f
        c.drawText("SETTLEMENT SURVIVAL v0.4", 65f, 55f, paint)
        paint.textSize = 20f
        c.drawText("Day $day • %02d:%02d".format(hour, minute), 68f, 90f, paint)

        paint.textSize = 17f
        val stats = "Wood $wood    Food $food    Water $cleanWater    Meat $meat"
        c.drawText(stats, 70f, 118f, paint)

        paint.color = Color.argb(210, 10, 20, 15)
        c.drawRoundRect(65f, h - 145f, w - 65f, h - 92f, 12f, 12f, paint)
        paint.color = Color.WHITE
        paint.textSize = 15f
        c.drawText("RPG Quest $quest • $questKills/3 Beast kills", 82f, h - 112f, paint)

        paint.color = if (attacking) Color.rgb(170, 50, 45) else Color.rgb(50, 55, 55)
        c.drawRoundRect(w - 520f, h - 78f, w - 260f, h - 25f, 16f, 16f, paint)
        c.drawRoundRect(w - 245f, h - 78f, w - 65f, h - 25f, 16f, 16f, paint)
        paint.color = Color.WHITE
        paint.textAlign = Paint.Align.CENTER
        paint.textSize = 18f
        c.drawText(if (attacking) "ATTACKING" else "ATTACK", w - 390f, h - 44f, paint)
        c.drawText(">", w - 155f, h - 44f, paint)
        paint.textAlign = Paint.Align.LEFT
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action != MotionEvent.ACTION_UP) return true
        val x = e.x
        val y = e.y
        val w = width.toFloat()
        val h = height.toFloat()

        if (x > w - 520f && x < w - 260f && y > h - 90f) {
            attacking = !attacking
            if (attacking) teamAttack()
            invalidate()
            return true
        }

        if (x > w - 245f && y > h - 90f) {
            advanceTime()
            invalidate()
            return true
        }

        if (y in 130f..(h - 95f)) {
            player.x = x.coerceIn(90f, w - 230f)
            player.y = y.coerceIn(175f, h - 130f)
            team.drop(1).forEachIndexed { i, u ->
                u.x = player.x + (i - 1) * 45f
                u.y = player.y + 55f
            }
            checkBeastEncounter()
            saveGame()
            invalidate()
        }
        return true
    }

    private fun checkBeastEncounter() {
        val b = beasts.minByOrNull { hypot(it.x - player.x, it.y - player.y) } ?: return
        if (hypot(b.x - player.x, b.y - player.y) < 90f) {
            selected = b
            attacking = true
            teamAttack()
        }
    }

    private fun teamAttack() {
        val b = selected ?: beasts.minByOrNull { hypot(it.x - player.x, it.y - player.y) }
        if (b == null) return
        selected = b
        b.hp -= team.sumOf { it.damage() } + powerBonus(b.power)
        if (b.hp <= 0) {
            beasts.remove(b)
            meat += 2
            questKills++
            team.forEach { it.addXp(12) }
            if (questKills >= 3) {
                quest++
                questKills = 0
                wood += 10
                food += 4
            }
            selected = null
            attacking = false
        } else {
            val target = team[rng.nextInt(team.size)]
            target.hp -= 8 + powerBonus(b.power)
            if (target.hp <= 0) target.hp = 1
        }
        saveGame()
    }
}
