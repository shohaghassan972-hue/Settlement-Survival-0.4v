# Settlement Survival v0.4

Lightweight Android survival settlement prototype. Includes an isometric-style map, trees, river, houses, villagers, resources, day/night cycle, build mode and fast time.


## v0.4
- RPG progression with XP and character levels
- Exactly 4 characters: Player (Dark), NPC1 (Water), NPC2 (Light), NPC3 (Fire)
- Coordinated player attack and automatic team defense
- Magic Beasts hidden in the forest with 8 elemental powers
- River-only water source, purification building, and cooking building
- Farming, well, watch tower, extra houses, and separate defense building are excluded
- SharedPreferences autosave and lifecycle save; data schema is version-independent
- Requires the same applicationId and signing key for APK updates to preserve app data


## v0.4.1 Map Update
The app opens directly on the new illustrated top-down map. Application ID is unchanged and versionCode is 5 for update installation.
